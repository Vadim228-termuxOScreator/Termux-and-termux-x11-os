#!/data/data/com.termux/files/usr/bin/bash

mkdir -p ~/Winsys/applications ~/.local/share/applications

cat > ~/Winsys/applications/python-launch.desktop <<EOF
[Desktop Entry]
Name=Python Runner
Exec=python3 %f
Type=Application
MimeType=text/x-python;
EOF

cat > ~/Winsys/applications/mp3-player.desktop <<EOF
[Desktop Entry]
Name=MPV Audio Player
Exec=mpv %f
Type=Application
MimeType=audio/mpeg;audio/mp3;
EOF

cp ~/Winsys/applications/*.desktop ~/.local/share/applications/
update-desktop-database ~/.local/share/applications
echo "Приложения добавлены!"
