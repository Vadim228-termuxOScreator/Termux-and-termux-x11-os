#!/data/data/com.termux/files/usr/bin/bash

# [1/3] Запуск X-сервера
echo "[1/3] Запуск Termux X11..."
termux-x11 :0 &
export DISPLAY=:0
sleep 3

# [2/3] Права на все .sh скрипты
echo "[2/3] Установка прав на скрипты..."
chmod +x ~/WinSys/*.sh
chmod +x ~/WinSys/*/*.sh 2>/dev/null

# [3/3] Старт системы WinSys
echo "[3/3] Запуск WinSys..."
bash ~/WinSys/desktop.sh
