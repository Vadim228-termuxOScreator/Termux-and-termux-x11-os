#!/data/data/com.termux/files/usr/bin/bash

echo "[1/4] Обновление и установка базовых пакетов..."
pkg update -y && pkg upgrade -y
pkg install -y x11-repo
pkg install -y termux-x11 wget unzip git pulseaudio -y

echo "[2/4] Доступ к хранилищу, нажми разрешить..."
termux-setup-storage

echo "[3/4] Установка графических пакетов..."
pkg install -y zenity openbox xdotool xorg-xmessage feh mpv ffmpeg firefox leafpad mtpaint pcmanfm abiword gnumeric galculator htop -y

echo "[4/4] Готово. Запусти Termux X11 и выполни:"
echo "bash ~/WinSys/stage2.sh"
