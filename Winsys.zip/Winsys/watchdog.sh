#!/bin/bash

# Переменные
X11_STARTED=0
BSOD_IMAGE="$HOME/Winsys/error/BSOD.pnh"  # ты писал .pnh

while true; do
    # Если нет процесса desktop.sh
    if ! pgrep -f "desktop.sh" >/dev/null; then
        # Попытка запустить termux-x11, если он не активен
        if ! pgrep -f "termux-x11" >/dev/null && [ $X11_STARTED -eq 0 ]; then
            echo "[Watchdog] Перезапуск Termux X11..."
            termux-x11 :0 &
            sleep 3
            export DISPLAY=:0
            X11_STARTED=1
        fi

        # Ожидание, пока DISPLAY станет доступен (макс 5 сек)
        for i in {1..5}; do
            if xdpyinfo >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done

        # Запуск BSOD
        echo "[Watchdog] Критическая ошибка! Запуск BSOD..."
        export DISPLAY=:0
        feh -F "$BSOD_IMAGE" &
        break
    fi

    # Можно добавить тут проверку обновлений (если нужно)
    # Например, если есть файл ~/Winsys/update.flag — применить обнову

    sleep 2
done
